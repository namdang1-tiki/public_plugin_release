//
//  StoragePermissionStrategy.h
//  permission_handler
//
//  Created by Frank Gregor on 06.11.19.
//

#import <Foundation/Foundation.h>
#import "PermissionStrategy.h"

NS_ASSUME_NONNULL_BEGIN

@interface StoragePermissionStrategy : NSObject <PermissionStrategy>

@end

NS_ASSUME_NONNULL_END
