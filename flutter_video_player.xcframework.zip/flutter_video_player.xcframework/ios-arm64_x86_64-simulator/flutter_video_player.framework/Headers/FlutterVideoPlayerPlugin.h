#import <Flutter/Flutter.h>

@interface FlutterVideoPlayerPlugin : NSObject<FlutterPlugin>
@end
